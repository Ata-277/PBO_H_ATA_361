package com.praktikum.actions;

public interface AdminActions {

    void manageItem();
    void manageUser();

}
