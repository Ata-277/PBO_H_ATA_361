package com.praktikum.actions;

public interface MahasiswaActions {

    void reportItem();
    void viewreportItem();

}
